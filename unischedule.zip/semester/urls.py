# semester/urls.py

from django.urls import path

urlpatterns = [
    # API endpoints مربوط به Semester اینجا اضافه می‌شن
]
